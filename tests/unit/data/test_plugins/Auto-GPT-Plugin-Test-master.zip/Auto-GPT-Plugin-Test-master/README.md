# Auto-GPT-Vicuna Plugin

Allows chat completions with auto-vicuna.

See https://github.com/BillSchumacher/Auto-Vicuna for setup details.

