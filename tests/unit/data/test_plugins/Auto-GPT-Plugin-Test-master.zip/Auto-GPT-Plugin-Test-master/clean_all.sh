rm build -rf
rm dist -rf
rm __pycache__ -rf
rm *.egg-info -rf
rm **/*.egg-info -rf
rm *.pyc -rf
rm **/*.pyc -rf
rm reports -rf